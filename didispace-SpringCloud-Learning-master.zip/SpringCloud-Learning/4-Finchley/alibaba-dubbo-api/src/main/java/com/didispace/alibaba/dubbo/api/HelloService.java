package com.didispace.alibaba.dubbo.api;

/**
 * Created by 程序猿DD/翟永超 on 2019/8/5.
 * <p>
 * Blog: http://blog.didispace.com/
 * Github: https://github.com/dyc87112/
 */
public interface HelloService {

    String hello(String name);

}
